package com.group7;

import it.unisa.dia.gas.jpbc.Element;

import java.math.BigInteger;

public class M1 {
    final Element C1;
    final BigInteger C2;

    public M1(Element c1, BigInteger c2) {
        C1 = c1;
        C2 = c2;
    }
}
