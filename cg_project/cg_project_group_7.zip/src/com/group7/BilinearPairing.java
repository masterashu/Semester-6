package com.group7;


import it.unisa.dia.gas.jpbc.Element;

public interface BilinearPairing {
    Element pair(Element x, Element y);
}
