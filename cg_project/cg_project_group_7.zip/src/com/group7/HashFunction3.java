package com.group7;

import it.unisa.dia.gas.jpbc.Element;

public interface HashFunction3 {
    Element hash(byte[] data);
}
